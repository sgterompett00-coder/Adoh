# Daftar SFX (buat sendiri, simpan sebagai <nama>.mp3)

Aktifkan dengan menambahkan namanya ke `AVAILABLE_SFX` di `src/data/soundCues.ts`. Tidak ada file audio yang dibuat otomatis.

| Timestamp | Nama SFX | Adegan | Durasi (dtk) | Volume relatif | Penempatan |
|---|---|---|---|---|---|
| 00:00.00 | night-ambience | B01 | 32 | 0.1 | Loop dasar B01-B07 |
| 00:00.30 | mysterious-movement | B01 | 0.8 | 0.45 | Sandal berkedut / bayangan |
| 00:01.20 | suspense-hit | B01 | 0.6 | 0.45 | Cut ke wajah |
| 00:02.20 | running-whoosh | B01 | 0.8 | 0.5 | Lari, lompat, menikung |
| 00:02.30 | fast-footsteps | B01 | 2 | 0.35 | Kabur |
| 00:04.60 | soft-footsteps | B02 | 2 | 0.25 | Jinjit / mengerem |
| 00:05.60 | leaf-rustle | B02 | 0.8 | 0.3 | Dekat semak |
| 00:06.70 | suspense-pluck | B02 | 0.4 | 0.35 | Periksa sandal |
| 00:08.35 | comedic-idea-pop | B03 | 0.4 | 0.6 | Jari terangkat |
| 00:08.50 | light-sparkle | B03 | 0.6 | 0.3 | Bola lampu |
| 00:12.10 | cardboard-movement | B03 | 0.6 | 0.35 | Kotak diangkat / goyang |
| 00:12.70 | rope-movement | B03 | 0.6 | 0.3 | Tali diambil, diikat, ditarik |
| 00:13.60 | rope-movement | B04 | 0.4 | 0.4 | Tali diambil, diikat, ditarik |
| 00:14.00 | cardboard-movement | B04 | 0.5 | 0.45 | Kotak diangkat / goyang |
| 00:14.50 | comedic-impact | B04 | 0.4 | 0.65 | Benturan kotak / ember |
| 00:16.00 | rope-movement | B04 | 1.2 | 0.3 | Tali diambil, diikat, ditarik |
| 00:18.10 | success-pop | B04 | 0.4 | 0.45 | Jebakan siap |
| 00:18.80 | crickets | B05 | 5.1 | 0.2 | Menunggu |
| 00:18.80 | wind-ambience | B05 | 5.1 | 0.12 | Angin |
| 00:21.90 | comedic-snore | B05 | 1.2 | 0.25 | Tertidur |
| 00:23.95 | mysterious-movement | B06 | 0.8 | 0.5 | Sandal berkedut / bayangan |
| 00:24.20 | suspense-drone | B06 | 7.8 | 0.22 | Ketegangan |
| 00:25.00 | subtle-footsteps | B06 | 3 | 0.3 | Sosok mendekat |
| 00:27.50 | rising-tension | B06 | 1.4 | 0.35 | Menjelang cut |
| 00:30.10 | sandal-lift | B07 | 0.5 | 0.6 | Sandal diangkat |
| 00:31.15 | rope-movement | B07 | 0.3 | 0.45 | Tali diambil, diikat, ditarik |
| 00:31.40 | comedic-failure-sting | B07 | 0.6 | 0.5 | Jebakan gagal |
| 00:32.05 | running-whoosh | B08 | 0.6 | 0.55 | Lari, lompat, menikung |
| 00:32.30 | chase-footsteps | B08 | 3.8 | 0.4 | Pengejaran |
| 00:33.70 | comedic-impact | B08 | 0.4 | 0.55 | Benturan kotak / ember |
| 00:35.30 | running-whoosh | B08 | 0.6 | 0.45 | Lari, lompat, menikung |
| 00:36.15 | wind-ambience | B09 | 8.8 | 0.2 | Angin |
| 00:36.15 | suspense-drone | B09 | 8.8 | 0.18 | Ketegangan |
| 00:37.05 | soft-footsteps | B09 | 0.8 | 0.35 | Jinjit / mengerem |
| 00:38.70 | old-door-creak | B09 | 0.9 | 0.3 | Pintu tua |
| 00:41.20 | door-handle | B10 | 0.5 | 0.55 | Pegang gagang |
| 00:42.40 | old-door-creak | B10 | 2.4 | 0.65 | Pintu tua |
| 00:43.40 | cinematic-swell | B10 | 1.6 | 0.4 | Mengintip |
| 00:44.40 | suspense-impact | B10 | 0.5 | 0.45 | Sebelum lampu |
| 00:45.00 | cinematic-reveal | B10 | 2 | 0.55 | Ruangan terungkap |
| 00:45.30 | suspense-drone | B11 | 5.8 | 0.15 | Ketegangan |
| 00:46.30 | magical-discovery | B11 | 1.5 | 0.25 | Sapuan sandal |
| 00:49.90 | sandal-drop | B11 | 0.4 | 0.4 | Sandal jatuh |
| 00:51.15 | mysterious-heartbeat | B12 | 6.8 | 0.3→0.55 | Menuju kursi |
| 00:51.15 | suspense-drone | B12 | 6.8 | 0.2→0.35 | Ketegangan |
| 00:58.00 | final-cinematic-boom | B12 | 0.6 | 0.75 | Tepat saat hitam, lalu hening |
