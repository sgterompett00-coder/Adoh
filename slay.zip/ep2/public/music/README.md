Letakkan bgm.mp3 di folder ini, lalu ubah HAS_MUSIC menjadi true di src/data/soundCues.ts.
