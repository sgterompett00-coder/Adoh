# Misteri Sandal Jepit Ep. 2: Sang Pencuri Sandal

Remotion (React + TypeScript), 1080×1920, 30 fps, 60 detik (1800 frame). Composition: `SandalEp2`.

## Menjalankan
Butuh Node.js 18 atau lebih baru dan koneksi internet (instalasi paket dan font Montserrat).

    npm install
    npm run typecheck
    npm run dev
    npm run render      # hasil: out/sang-pencuri-sandal.mp4

## Mengaktifkan audio (src/data/soundCues.ts)
1. Salin narasi ke `public/narasi.mp3`, lalu `HAS_NARRATION = true`.
2. Musik: `public/music/bgm.mp3`, lalu `HAS_MUSIC = true`.
3. SFX: simpan di `public/sounds/`, lalu isi `AVAILABLE_SFX` dengan nama file tanpa `.mp3`.

## Sinkronisasi: BELUM FINAL
Narasi belum tersedia. Waktu diambil dari SRT; batas di tengah cue adalah perkiraan (`estimated: true` di `captions.ts`).
Setelah `narasi.mp3` ada:
- Cek hening di J3 (≈30,15) dan J5 (≈41,15) pada `src/data/timing.ts`. Geser `at` ke titik hening yang sebenarnya.
- Samakan angka yang sama di `captions.ts` dan `beats.ts` (30.15 dan 41.15).
- Koreksi batas frasa lain di `captions.ts` dan awal beat di `beats.ts`.
- Cue SFX memakai detik video tetap; sesuaikan bila jeda digeser.
- Durasi total tetap 60 detik (`TOTAL_SECONDS` di `beats.ts`); ubah bila total jeda berubah.

## Struktur
    src/Root.tsx, src/Video.tsx     komposisi, urutan beat, whip pan
    src/scenes/B01..B12.tsx         satu komponen per beat
    src/components/                 karakter, lingkungan, properti, efek, subtitle, audio
    src/data/                       beats, captions, layout, timing, soundCues

## Catatan visual
Semua gambar vektor SVG buatan kode (tidak memakai file gambar). Sandal utama, hoodie, dan rambut didefinisikan sekali agar konsisten.
Frame terakhir Episode 1 belum tersedia, jadi kontinuitas pembuka mengikuti deskripsi brief.

## Versi
Remotion dipatok ke 4.0.543. Semua paket `remotion` dan `@remotion/*` harus berversi sama.
Lisensi Remotion: cek https://www.remotion.dev/license sebelum pemakaian komersial.
