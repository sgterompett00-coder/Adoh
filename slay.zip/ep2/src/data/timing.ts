import {FPS} from './layout';

/** Jeda sinematik (Opsi B). `at` = posisi di waktu AUDIO. verify = wajib dicek di narasi.mp3 */
export const PAUSES = [
  {id: 'J1', at: 13.41, add: 1.5, verify: false},
  {id: 'J2', at: 22.39, add: 2.0, verify: false},
  {id: 'J3', at: 30.15, add: 2.5, verify: true},
  {id: 'J4', at: 36.49, add: 2.5, verify: false},
  {id: 'J5', at: 41.15, add: 1.5, verify: true},
];

/** Waktu audio -> waktu video. afterPause: titik tepat di jeda dianggap sesudah jeda. */
export const toVideo = (a: number, afterPause = false) =>
  a + PAUSES.filter((p) => (afterPause ? p.at <= a : p.at < a)).reduce((s, p) => s + p.add, 0);

export const toFrame = (seconds: number) => Math.round(seconds * FPS);

/** Potongan narasi di antara jeda. File MP3 tidak diubah. */
export const NARRATION_SEGMENTS = [0, ...PAUSES.map((p) => p.at)].map((start, i) => ({
  audioStart: start,
  audioEnd: PAUSES[i]?.at as number | undefined,
  videoStart: toVideo(start, true),
}));
