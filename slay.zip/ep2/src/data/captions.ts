export type Caption = {start: number; end: number; text: string; pos: 'top' | 'bottom'; estimated: boolean};

// Waktu AUDIO. estimated = salah satu batas diperkirakan di dalam cue SRT (belum final).
// *kata* = kuning, | = baris baru.
const c = (start: number, end: number, text: string, pos: 'top' | 'bottom', estimated = true): Caption =>
  ({start, end, text, pos, estimated});

export const CAPTIONS: Caption[] = [
  c(0.12, 1.76, 'Setelah melihat|*sandal* itu', 'top'),
  c(1.76, 2.74, '*bergerak* *sendiri,*', 'top'),
  c(2.74, 3.72, 'aku langsung *kabur!*', 'bottom'),
  c(4.42, 5.86, 'Tapi karena|*penasaran,*', 'bottom'),
  c(5.86, 6.82, 'aku balik lagi.', 'bottom'),
  c(7.46, 8.28, 'Aku punya *ide.*', 'bottom', false),
  c(8.9, 10.89, 'Kalau pencurinya|suka *sandal,*', 'bottom'),
  c(10.89, 13.08, 'berarti kita kasih|dia *umpan!*', 'bottom'),
  c(13.74, 15.34, 'Aku memasang|*jebakan*', 'bottom'),
  c(15.34, 17.34, 'paling *canggih* yang|pernah kubuat.', 'bottom'),
  c(17.34, 18.74, 'Setelah itu, aku', 'bottom'),
  c(18.74, 20.75, '*bersembunyi*|dan menunggu.', 'bottom'),
  c(20.75, 22.0, '*Sampai* *akhirnya...*', 'bottom'),
  c(22.78, 25.45, 'sesuatu muncul dari|*kegelapan.*', 'top'),
  c(25.45, 26.56, '*Dan* *benar* *saja...*', 'bottom'),
  c(26.56, 28.55, 'dia *mengambil*|sandal itu!', 'bottom'),
  c(28.55, 30.15, 'Aku langsung|*mengejarnya!*', 'bottom'),
  c(30.15, 32.07, 'Sampai akhirnya,|dia masuk ke', 'bottom'),
  c(32.07, 33.6, 'sebuah|*bangunan* *tua.*', 'bottom'),
  c(33.6, 36.18, 'Aku membuka|pintunya *perlahan...*', 'top'),
  c(36.8, 38.55, '...dan ternyata|di dalamnya', 'top'),
  c(38.55, 41.15, 'ada *ratusan* *sandal*|jepit yang *hilang!*', 'top'),
  c(41.15, 42.4, '*Tapi* *tunggu* *dulu...*', 'top'),
  c(42.4, 44.03, 'aku melihat sesuatu', 'top'),
  c(44.03, 45.3, 'yang lebih|*mengejutkan.*', 'top'),
];
