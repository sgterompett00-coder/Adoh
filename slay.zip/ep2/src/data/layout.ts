export const WIDTH = 1080;
export const HEIGHT = 1920;
export const FPS = 30;

export const SUBTITLE_Y = {top: 360, bottom: 1400} as const;
export const SUBTITLE_BOX = {x: 120, width: 800};

export const C = {
  ink: '#0B0A0D', night: '#1B2347', mid: '#2E3A66', deep: '#12152B', warm: '#FFC76B',
  sandal: '#24348C', sandalLight: '#3F55B5', hoodie: '#D9D8DC', hoodieShade: '#B4B3C0',
  hair: '#4A2A1B', cardboard: '#C9965A', moon: '#F3F0DC', red: '#7A1A22', yellow: '#FFD62E',
} as const;
