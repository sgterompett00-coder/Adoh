import {toFrame, toVideo} from './timing';

export const TOTAL_SECONDS = 60;
export const TOTAL_FRAMES = toFrame(TOTAL_SECONDS);

// [id, judul, awal (waktu audio), mulai sesudah jeda?]. Batas di tengah cue SRT = perkiraan.
const raw = [
  ['B01', 'Sandal yang bergerak', 0, false],
  ['B02', 'Balik lagi', 4.42, false],
  ['B03', 'Ide jebakan', 7.46, false],
  ['B04', 'Memasang jebakan', 13.41, false],
  ['B05', 'Menunggu', 17.3, false],
  ['B06', 'Sesuatu muncul', 22.39, false],
  ['B07', 'Umpan diambil', 25.45, false],
  ['B08', 'Pengejaran', 28.55, false],
  ['B09', 'Bangunan tua', 30.15, true],
  ['B10', 'Membuka pintu', 33.6, false],
  ['B11', 'Ratusan sandal', 36.8, false],
  ['B12', 'Sosok di kursi', 41.15, true],
] as const;

export const BEATS = raw.map(([id, title, audio, after], i) => {
  const from = toFrame(toVideo(audio, after));
  const next = raw[i + 1];
  const end = next ? toFrame(toVideo(next[2], next[3])) : TOTAL_FRAMES;
  return {id, title, from, durationInFrames: end - from};
});
