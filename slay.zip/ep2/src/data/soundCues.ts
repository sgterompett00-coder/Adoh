/** AKTIFKAN setelah file tersedia. */
export const HAS_NARRATION: boolean = false; // public/narasi.mp3
export const HAS_MUSIC: boolean = false; // public/music/bgm.mp3
/** Isi dengan nama SFX yang filenya sudah ada di public/sounds/, mis. ['night-ambience'] */
export const AVAILABLE_SFX: string[] = [];

export type Cue = {at: number; name: string; dur: number; vol: number; volEnd?: number; loop?: boolean};
const q = (at: number, name: string, dur: number, vol: number, extra: Partial<Cue> = {}): Cue =>
  ({at, name, dur, vol, ...extra});

// at = detik VIDEO (Opsi B)
export const SOUND_CUES: Cue[] = [
  q(0, 'night-ambience', 32, 0.1, {loop: true}), q(0.3, 'mysterious-movement', 0.8, 0.45),
  q(1.2, 'suspense-hit', 0.6, 0.45), q(2.2, 'running-whoosh', 0.8, 0.5), q(2.3, 'fast-footsteps', 2, 0.35),
  q(4.6, 'soft-footsteps', 2, 0.25), q(5.6, 'leaf-rustle', 0.8, 0.3), q(6.7, 'suspense-pluck', 0.4, 0.35),
  q(8.35, 'comedic-idea-pop', 0.4, 0.6), q(8.5, 'light-sparkle', 0.6, 0.3),
  q(12.1, 'cardboard-movement', 0.6, 0.35), q(12.7, 'rope-movement', 0.6, 0.3),
  q(13.6, 'rope-movement', 0.4, 0.4), q(14, 'cardboard-movement', 0.5, 0.45),
  q(14.5, 'comedic-impact', 0.4, 0.65), q(16, 'rope-movement', 1.2, 0.3), q(18.1, 'success-pop', 0.4, 0.45),
  q(18.8, 'crickets', 5.1, 0.2, {loop: true}), q(18.8, 'wind-ambience', 5.1, 0.12, {loop: true}),
  q(21.9, 'comedic-snore', 1.2, 0.25), q(23.95, 'mysterious-movement', 0.8, 0.5),
  q(24.2, 'suspense-drone', 7.8, 0.22, {loop: true}), q(25, 'subtle-footsteps', 3, 0.3),
  q(27.5, 'rising-tension', 1.4, 0.35), q(30.1, 'sandal-lift', 0.5, 0.6), q(31.15, 'rope-movement', 0.3, 0.45),
  q(31.4, 'comedic-failure-sting', 0.6, 0.5), q(32.05, 'running-whoosh', 0.6, 0.55),
  q(32.3, 'chase-footsteps', 3.8, 0.4), q(33.7, 'comedic-impact', 0.4, 0.55), q(35.3, 'running-whoosh', 0.6, 0.45),
  q(36.15, 'wind-ambience', 8.8, 0.2, {loop: true}), q(36.15, 'suspense-drone', 8.8, 0.18, {loop: true}),
  q(37.05, 'soft-footsteps', 0.8, 0.35), q(38.7, 'old-door-creak', 0.9, 0.3), q(41.2, 'door-handle', 0.5, 0.55),
  q(42.4, 'old-door-creak', 2.4, 0.65), q(43.4, 'cinematic-swell', 1.6, 0.4), q(44.4, 'suspense-impact', 0.5, 0.45),
  q(45, 'cinematic-reveal', 2, 0.55), q(45.3, 'suspense-drone', 5.8, 0.15, {loop: true}),
  q(46.3, 'magical-discovery', 1.5, 0.25), q(49.9, 'sandal-drop', 0.4, 0.4),
  q(51.15, 'mysterious-heartbeat', 6.8, 0.3, {volEnd: 0.55, loop: true}),
  q(51.15, 'suspense-drone', 6.8, 0.2, {volEnd: 0.35, loop: true}), q(58, 'final-cinematic-boom', 0.6, 0.75),
];

// [mulai video, volume saat narasi, volume saat jeda]
export const MUSIC_SECTIONS: [number, number, number][] = [
  [0, 0.1, 0.18], [7.46, 0.12, 0.22], [18.8, 0.07, 0.1], [23.89, 0.1, 0.18], [32.05, 0.12, 0.3],
  [36.15, 0.08, 0.15], [45, 0.12, 0.25], [51.15, 0.08, 0.12], [58, 0, 0],
];
