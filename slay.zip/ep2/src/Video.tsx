import type {ComponentType} from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame, useVideoConfig, interpolate} from 'remotion';
import {AudioTracks} from './components/AudioTracks';
import {Subtitles} from './components/Subtitles';
import {BEATS} from './data/beats';
import {B01} from './scenes/B01';
import {B02} from './scenes/B02';
import {B03} from './scenes/B03';
import {B04} from './scenes/B04';
import {B05} from './scenes/B05';
import {B06} from './scenes/B06';
import {B07} from './scenes/B07';
import {B08} from './scenes/B08';
import {B09} from './scenes/B09';
import {B10} from './scenes/B10';
import {B11} from './scenes/B11';
import {B12} from './scenes/B12';

const SCENES: ComponentType[] = [B01, B02, B03, B04, B05, B06, B07, B08, B09, B10, B11, B12];
// Whip pan: frame keluar & masuk. dir = arah geser.
const WHIP: Record<string, {in?: number; out?: number}> = {
  B01: {out: -1}, B02: {in: -1}, B07: {out: 1}, B08: {in: 1},
};

const Shot = ({id, Scene}: {id: string; Scene: ComponentType}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const beat = BEATS.find((b) => b.id === id);
  const len = beat?.durationInFrames ?? durationInFrames;
  const w = WHIP[id] ?? {};
  const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
  const enter = w.in ? interpolate(frame, [0, 4], [1, 0], clamp) : 0;
  const exit = w.out ? interpolate(frame, [len - 4, len], [0, 1], clamp) : 0;
  const x = -(w.in ?? 0) * enter * 700 + (w.out ?? 0) * exit * 700;
  const blur = Math.max(enter, exit) * 28;
  // B04 -> B05: langit menggelap
  const dark = id === 'B04' ? interpolate(frame, [len - 12, len], [0, 0.55], clamp)
    : id === 'B05' ? interpolate(frame, [0, 8], [0.55, 0], clamp) : 0;
  return (
    <AbsoluteFill style={{filter: blur ? `blur(${blur}px)` : undefined, transform: blur ? `translateX(${x}px) scale(1.04)` : undefined}}>
      <svg width="100%" height="100%" viewBox="0 0 1080 1920"><Scene /></svg>
      <AbsoluteFill style={{backgroundColor: '#05061A', opacity: dark}} />
    </AbsoluteFill>
  );
};

export const Video = () => (
  <AbsoluteFill style={{backgroundColor: 'black'}}>
    {BEATS.map((b, i) => (
      <Sequence key={b.id} name={`${b.id} ${b.title}`} from={b.from} durationInFrames={b.durationInFrames}>
        <Shot id={b.id} Scene={SCENES[i]} />
      </Sequence>
    ))}
    <Subtitles />
    <AudioTracks />
  </AbsoluteFill>
);
