import {Composition} from 'remotion';
import {Video} from './Video';
import {FPS, HEIGHT, WIDTH} from './data/layout';
import {TOTAL_FRAMES} from './data/beats';

export const Root = () => (
  <Composition id="SandalEp2" component={Video} durationInFrames={TOTAL_FRAMES}
    fps={FPS} width={WIDTH} height={HEIGHT} />
);
