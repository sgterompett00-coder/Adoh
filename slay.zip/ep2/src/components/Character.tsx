import type {ReactNode} from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from '../data/layout';

export type Expr = 'curious' | 'confused' | 'smug' | 'suspicious' | 'shocked' | 'nervous' | 'panicked' | 'determined' | 'exhausted';
type P = [number, number];
type Props = {
  feet?: {x: number; y: number; h: number};
  head?: {x: number; y: number; d: number};
  expr: Expr; back?: boolean; lean?: number; squash?: number;
  handL?: P; handR?: P; footL?: P; footR?: P; look?: number; faceShift?: number; tilt?: number;
  holdR?: ReactNode; pointR?: boolean;
};
const ink = C.ink;
const L = {stroke: ink, strokeWidth: 10, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const};

const Face = ({expr, look, blink}: {expr: Expr; look: number; blink: boolean}) => {
  const line = (d: string, w = 12) => <path d={d} fill="none" {...L} strokeWidth={w} />;
  const eye = (x: number, rx: number, ry: number) =>
    <ellipse cx={x + look} cy={10} rx={rx} ry={blink ? 3 : ry} fill={ink} />;
  const wide = (x: number, r: number) => (
    <g><circle cx={x} cy={5} r={r} fill="white" {...L} /><circle cx={x + look} cy={8} r={blink ? 3 : 11} fill={ink} /></g>
  );
  const brows = (l: string, r: string) => <>{line(l, 14)}{line(r, 14)}</>;
  switch (expr) {
    case 'curious': return <>{eye(-55, 17, 25)}{eye(55, 17, 25)}{brows('M-85 -35 L-30 -35', 'M30 -55 Q60 -70 90 -50')}<ellipse cx={5} cy={80} rx={14} ry={18} fill={ink} /></>;
    case 'confused': return <>{eye(-55, 13, 17)}{eye(55, 20, 28)}{brows('M-85 -25 L-30 -30', 'M30 -50 L88 -68')}{line('M-35 82 L-12 68 L12 86 L36 72')}</>;
    case 'smug': return <>{eye(-55, 20, 14)}{eye(55, 20, 14)}{brows('M-95 -45 L-25 -12', 'M25 -12 L95 -45')}{line('M-45 72 Q10 112 62 55')}</>;
    case 'suspicious': return <>{eye(-55, 22, 10)}{eye(55, 22, 10)}{brows('M-90 -22 L-25 -10', 'M25 -10 L90 -22')}{line('M-25 82 Q0 70 30 82')}</>;
    case 'shocked': return <>{wide(-58, 40)}{wide(58, 40)}{brows('M-90 -65 Q-55 -85 -25 -65', 'M25 -65 Q55 -85 90 -65')}<ellipse cx={0} cy={95} rx={32} ry={40} fill="#8E2430" {...L} /></>;
    case 'nervous': return <>{wide(-55, 31)}{wide(55, 31)}{brows('M-85 -35 L-28 -58', 'M28 -58 L85 -35')}{line('M-42 85 q14 -18 28 0 t28 0 t28 0')}</>;
    case 'panicked': return <>{line('M-88 -15 L-35 10 L-88 35', 16)}{line('M88 -15 L35 10 L88 35', 16)}<path d="M-55 60 Q0 40 55 60 Q40 140 0 135 Q-40 140 -55 60Z" fill="#8E2430" {...L} /></>;
    case 'determined': return <>{eye(-55, 18, 19)}{eye(55, 18, 19)}{brows('M-95 -45 L-22 -8', 'M22 -8 L95 -45')}<path d="M-38 65 H40 L30 95 H-28Z" fill="white" {...L} />{line('M-33 80 H35', 6)}</>;
    case 'exhausted': return <>{line('M-82 12 Q-55 28 -28 12')}{line('M28 12 Q55 28 82 12')}{brows('M-82 -28 L-32 -38', 'M32 -38 L82 -28')}<ellipse cx={0} cy={90} rx={25} ry={30} fill="#8E2430" {...L} /></>;
  }
};

const Drop = ({x, y}: {x: number; y: number}) =>
  <path d={`M${x} ${y} q24 36 0 48 q-24 -12 0 -48Z`} fill="#8FD3FF" {...L} strokeWidth={6} />;

export const Character = ({feet, head, expr, back, lean = 0, squash = 1, handL = [-145, -185], handR = [145, -185],
  footL = [-55, -8], footR = [55, -8], look = 0, faceShift = 0, tilt = 0, holdR, pointR}: Props) => {
  const f = useCurrentFrame();
  const scale = head ? head.d / 330 : (feet?.h ?? 700) / 700;
  const x = head ? head.x : feet?.x ?? 540;
  const y = head ? head.y + 500 * scale : feet?.y ?? 1400;
  const breath = Math.sin(f / 9) * 4;
  const sway = Math.sin((f - 3) / 7) * 6; // follow-through rambut & tali
  const limb = (from: P, to: P, bend: number, w: number) => (
    <path d={`M${from[0]} ${from[1]} Q${(from[0] + to[0]) / 2 + bend} ${(from[1] + to[1]) / 2 + Math.abs(bend) / 2} ${to[0]} ${to[1]}`}
      fill="none" stroke={ink} strokeWidth={w} strokeLinecap="round" />
  );
  const arm = (sx: number, hand: P) => {
    const sh: P = [sx, -315 + breath];
    const mid: P = [sh[0] + (hand[0] - sh[0]) * 0.32, sh[1] + (hand[1] - sh[1]) * 0.32];
    return (
      <g>
        {limb(sh, hand, sx > 0 ? 25 : -25, 30)}
        <path d={`M${sh} L${mid}`} stroke={ink} strokeWidth={70} strokeLinecap="round" />
        <path d={`M${sh} L${mid}`} stroke={C.hoodie} strokeWidth={52} strokeLinecap="round" />
        <circle cx={hand[0]} cy={hand[1]} r={27} fill={ink} />
      </g>
    );
  };
  const spikes = `M-165 5 L${-212 + sway} -70 L-158 -80 L${-196 + sway} -152 L-112 -137 L${-108 + sway} -222 L-45 -168 L${8 + sway} -240 L50 -172 L${122 + sway} -218 L116 -138 L${200 + sway} -150 L152 -85 L${204 + sway} -45 L162 5`;
  return (
    <g transform={`translate(${x} ${y}) scale(${scale * (2 - squash)} ${scale * squash}) rotate(${lean})`}>
      <ellipse cx={0} cy={4} rx={130} ry={22} fill="black" opacity={0.35} />
      {limb([-40, -180], footL, -22, 34)}{limb([40, -180], footR, 22, 34)}
      {[footL, footR].map((p, i) => <ellipse key={i} cx={p[0] + 8} cy={p[1]} rx={40} ry={20} fill={ink} />)}
      {arm(-72, handL)}
      <path d={`M-72 ${-362 + breath} Q0 ${-385 + breath} 72 ${-362 + breath} L108 -170 Q0 -145 -108 -170Z`} fill={C.hoodie} {...L} />
      <path d="M35 -355 L105 -175 Q75 -165 45 -162Z" fill={C.hoodieShade} />
      {!back && <path d="M-62 -230 H62 L78 -172 Q0 -158 -78 -172Z" fill="none" {...L} strokeWidth={7} />}
      {arm(72, handR)}
      {pointR && <path d={`M${handR[0]} ${handR[1]} v-66`} stroke={ink} strokeWidth={24} strokeLinecap="round" />}
      {holdR && <g transform={`translate(${handR[0]} ${handR[1]})`}>{holdR}</g>}
      <g transform={`translate(0 ${-500 + breath}) rotate(${tilt})`}>
        <circle r={165} fill="white" {...L} />
        <path d="M120 -105 Q185 20 100 115 Q150 10 120 -105Z" fill="#D5D7E6" />
        {back ? (
          <path d={`${spikes} Q150 100 80 118 L45 150 L10 118 L-35 148 L-70 112 Q-155 90 -165 5Z`} fill={C.hair} {...L} />
        ) : (
          <>
            <g transform={`translate(${faceShift} 0)`}><Face expr={expr} look={look} blink={f % 78 < 4} /></g>
            <path d={`${spikes} L128 -62 L80 -92 L48 -55 L8 -102 L-32 -62 L-75 -100 L-112 -48 L-138 -68Z`} fill={C.hair} {...L} />
          </>
        )}
        {!back && expr === 'nervous' && <Drop x={150} y={-40} />}
        {!back && expr === 'panicked' && <><Drop x={205} y={-110 + (f % 8) * 5} /><Drop x={245} y={-40 + (f % 6) * 6} /></>}
      </g>
      {back ? <path d={`M-85 ${-355 + breath} Q0 -255 85 ${-355 + breath} Q0 -330 -85 ${-355 + breath}Z`} fill={C.hoodieShade} {...L} /> :
        [-1, 1].map((k) => (
          <g key={k}>
            <path d={`M${k * 30} -345 q${sway} 45 ${k * 6 + sway} 90`} fill="none" stroke={ink} strokeWidth={17} strokeLinecap="round" />
            <path d={`M${k * 30} -345 q${sway} 45 ${k * 6 + sway} 90`} fill="none" stroke="white" strokeWidth={8} strokeLinecap="round" />
          </g>
        ))}
    </g>
  );
};
