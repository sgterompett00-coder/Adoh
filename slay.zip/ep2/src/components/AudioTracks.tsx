import {Audio} from '@remotion/media';
import {Sequence, interpolate, staticFile} from 'remotion';
import {AVAILABLE_SFX, HAS_MUSIC, HAS_NARRATION, MUSIC_SECTIONS, SOUND_CUES} from '../data/soundCues';
import {NARRATION_SEGMENTS, toFrame, toVideo} from '../data/timing';
import {CAPTIONS} from '../data/captions';
import {FPS} from '../data/layout';
import {TOTAL_FRAMES} from '../data/beats';

const speech = CAPTIONS.map((c) => [toFrame(toVideo(c.start, true)), toFrame(toVideo(c.end))]);

const musicVolume = (f: number) => {
  const sec = [...MUSIC_SECTIONS].reverse().find(([s]) => f >= toFrame(s)) ?? MUSIC_SECTIONS[0];
  // 1 = ada narasi, 0 = jeda; transisi 7 frame
  const talking = Math.max(0, ...speech.map(([a, b]) =>
    interpolate(f, [a - 7, a, b, b + 7], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})));
  return sec[2] + (sec[1] - sec[2]) * talking;
};

export const AudioTracks = () => (
  <>
    {HAS_NARRATION && NARRATION_SEGMENTS.map((s) => (
      <Sequence key={s.audioStart} from={toFrame(s.videoStart)}
        durationInFrames={s.audioEnd ? toFrame(s.audioEnd) - toFrame(s.audioStart) : TOTAL_FRAMES - toFrame(s.videoStart)}>
        <Audio src={staticFile('narasi.mp3')} trimBefore={toFrame(s.audioStart)} />
      </Sequence>
    ))}
    {HAS_MUSIC && (
      <Sequence durationInFrames={toFrame(58)}>
        <Audio src={staticFile('music/bgm.mp3')} loop volume={musicVolume} />
      </Sequence>
    )}
    {SOUND_CUES.filter((c) => AVAILABLE_SFX.includes(c.name)).map((c) => (
      <Sequence key={`${c.name}-${c.at}`} from={toFrame(c.at)} durationInFrames={Math.max(1, toFrame(c.dur))}>
        <Audio src={staticFile(`sounds/${c.name}.mp3`)} loop={c.loop}
          volume={(f) => interpolate(f, [0, c.dur * FPS], [c.vol, c.volEnd ?? c.vol], {extrapolateRight: 'clamp'})} />
      </Sequence>
    ))}
  </>
);
