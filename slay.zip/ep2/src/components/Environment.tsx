import {random, useCurrentFrame} from 'remotion';
import {C} from '../data/layout';
import {Sandal} from './Props';

const ink = C.ink;

export const Sky = ({moon = [800, 400]}: {moon?: number[]}) => {
  const f = useCurrentFrame();
  return (
    <g>
      <defs><linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#0D1230" /><stop offset="1" stopColor="#3A4678" />
      </linearGradient></defs>
      <rect x={-300} y={-300} width={1680} height={1600} fill="url(#sky)" />
      {Array.from({length: 40}, (_, i) => <circle key={i} cx={random(`sx${i}`) * 1080} cy={random(`sy${i}`) * 650} r={2 + (i % 3)} fill="white" opacity={0.35 + 0.3 * Math.sin(f / 12 + i)} />)}
      <circle cx={moon[0]} cy={moon[1]} r={125} fill={C.moon} opacity={0.12} />
      <circle cx={moon[0]} cy={moon[1]} r={75} fill={C.moon} />
      {[0, 1, 2].map((i) => <ellipse key={i} cx={((i * 450 + f * 0.8) % 1500) - 200} cy={300 + i * 130} rx={230} ry={38} fill="#4B5890" opacity={0.45} />)}
    </g>
  );
};

export const Bush = ({x, y, r, seed, blur = 0}: {x: number; y: number; r: number; seed: string; blur?: number}) => {
  const f = useCurrentFrame();
  return (
    <g style={blur ? {filter: `blur(${blur}px)`} : undefined}>
      {Array.from({length: 34}, (_, i) => {
        const a = random(`${seed}a${i}`) * Math.PI * 2;
        const d = Math.sqrt(random(`${seed}d${i}`)) * r;
        const lx = x + Math.cos(a) * d;
        const ly = y + Math.sin(a) * d * 0.75;
        const rot = random(`${seed}r${i}`) * 180 - 90 + Math.sin(f / 18 + i) * 4;
        return <path key={i} transform={`translate(${lx} ${ly}) rotate(${rot}) scale(${r / 200})`} d="M0 40 C-60 0 -40 -70 0 -105 C40 -70 60 0 0 40Z"
          fill={['#17342F', '#1F4A3C', '#2B5E47'][i % 3]} stroke={ink} strokeWidth={6} />;
      })}
    </g>
  );
};

const Win = ({x, y, w, h, on}: {x: number; y: number; w: number; h: number; on: boolean}) => (
  <g stroke={ink} strokeWidth={8}>
    {on && <rect x={x - 25} y={y - 25} width={w + 50} height={h + 50} fill={C.warm} opacity={0.18} stroke="none" />}
    <rect x={x} y={y} width={w} height={h} fill={on ? C.warm : '#1A2040'} />
    <path d={`M${x + w / 2} ${y} v${h} M${x} ${y + h / 2} h${w}`} />
  </g>
);

export const Ground = ({horizon, vx, color = '#3B3448'}: {horizon: number; vx: number; color?: string}) => (
  <g>
    <rect x={-300} y={horizon} width={1680} height={2300 - horizon} fill={color} />
    <g stroke="black" strokeOpacity={0.25} strokeWidth={5}>
      {Array.from({length: 13}, (_, i) => <path key={i} d={`M${vx} ${horizon} L${(i - 6) * 360 + 540} 2100`} />)}
      {[35, 100, 200, 350, 570, 880].map((d) => <path key={d} d={`M-300 ${horizon + d} H1380`} />)}
    </g>
    {Array.from({length: 45}, (_, i) => {
      const d = random(`pb${i}`);
      return <ellipse key={i} cx={random(`px${i}`) * 1080} cy={horizon + 40 + d * d * 900} rx={8 + d * 22} ry={4 + d * 9} fill="#5A5068" stroke={ink} strokeWidth={3} />;
    })}
  </g>
);

/** Halaman rumah (B01-B07). pan = geser kamera horizontal untuk parallax. */
export const Yard = ({pan = 0, dim = 0, moon, lightOff = false, horizon = 960}: {pan?: number; dim?: number; moon?: number[]; lightOff?: boolean; horizon?: number}) => (
  <g>
    <g transform={`translate(${pan * 0.1} 0)`}><Sky moon={moon} /></g>
    <g transform={`translate(${pan * 0.3} ${horizon - 960})`}>
      <path d="M-200 960 V690 L40 560 L260 700 V960Z M860 960 V640 L1040 540 L1300 700 V960Z" fill="#232B55" stroke={ink} strokeWidth={7} />
      <Bush x={170} y={720} r={190} seed="tree" />
    </g>
    <g transform={`translate(${pan * 0.6} ${horizon - 960})`} stroke={ink} strokeWidth={9} strokeLinejoin="round">
      <path d="M360 960 V620 H900 V960Z" fill="#4A5078" />
      <path d="M900 960 V620 L1080 660 V960Z" fill="#363B62" />
      <path d="M320 630 L560 480 L920 560 L1130 665 L900 630Z" fill="#242946" />
      <Win x={720} y={690} w={120} h={140} on />
      <Win x={430} y={700} w={110} h={120} on={!lightOff} />
      <path d="M560 960 V760 H665 V960Z" fill="#2B2438" />
      <path d="M520 960 H700 L720 990 H500Z" fill="#6C6A88" />
      <path d="M-300 960 V800 H330 V960Z" fill="#555A7C" />
    </g>
    <Ground horizon={horizon} vx={610 + pan * 0.4} />
    <g transform={`translate(${pan} ${horizon - 960})`}><Bush x={40} y={990} r={170} seed="b1" /><Bush x={1050} y={1000} r={140} seed="b2" /></g>
    <rect x={-300} y={-300} width={1680} height={2500} fill="#05061A" opacity={dim} />
  </g>
);

export const Wall = ({edge}: {edge: number}) => (
  <g stroke={ink} strokeWidth={10}>
    <path d={`M-300 -100 H${edge} L${edge - 20} 2100 H-300Z`} fill="#5E607C" />
    <path d={`M${edge - 45} -100 V2100`} stroke="#43445E" strokeWidth={30} />
    <path d="M40 420 l60 70 -20 60 M70 1300 l-50 90 30 70" fill="none" strokeWidth={6} />
  </g>
);

export const Alley = ({scroll}: {scroll: number}) => {
  const v = {x: 900, y: 760};
  const at = (x: number, y: number, t: number) => [v.x + (x - v.x) * t, v.y + (y - v.y) * t];
  return (
    <g>
      <Sky moon={[760, 260]} />
      <path d={`M-100 80 L${v.x - 40} ${v.y - 150} V${v.y + 40} L-100 1500Z`} fill="#454B73" stroke={ink} strokeWidth={9} />
      <path d={`M1200 200 L${v.x + 90} ${v.y - 140} V${v.y + 40} L1200 1450Z`} fill="#30355A" stroke={ink} strokeWidth={9} />
      <Ground horizon={v.y + 40} vx={v.x} color="#34304A" />
      {/* jendela & tiang bergerak mengikuti lari (parallax) */}
      {[0, 1, 2, 3, 4].map((i) => {
        const t = 0.12 + 0.98 * (((i / 5 + scroll) % 1) ** 2);
        const p = [at(60, 520, t), at(260, 560, t), at(260, 900, t), at(60, 960, t)];
        return (
          <g key={i} stroke={ink} strokeWidth={4 + t * 6}>
            <path d={`M${p.join(' L')}Z`} fill={i % 2 ? C.warm : '#1C2142'} />
            <path d={`M${at(-70, 300, t)} L${at(-70, 1480, t)}`} strokeWidth={10 + t * 28} />
          </g>
        );
      })}
      <path d={`M180 360 Q500 500 ${v.x - 30} 620`} fill="none" stroke={ink} strokeWidth={5} />
      {[[330, 420], [520, 485], [680, 540]].map(([x, y], i) => <path key={i} d={`M${x} ${y} l80 22 -12 110 -75 -20Z`} fill={['#8C5A68', '#5E7C8C', '#8A8660'][i]} stroke={ink} strokeWidth={5} />)}
    </g>
  );
};

export const OldBuilding = () => (
  <g>
    <Sky moon={[900, 270]} />
    <Ground horizon={1250} vx={600} color="#2A2840" />
    <g stroke={ink} strokeWidth={10} strokeLinejoin="round">
      <path d="M110 1265 L150 700 L540 420 L990 730 L1010 1265Z" fill="#4B4A66" />
      <path d="M80 730 L540 390 L1050 760 L1000 790 L540 470 L135 765Z" fill="#25233A" />
      {Array.from({length: 11}, (_, i) => <path key={i} d={`M${185 + i * 75} ${780 - (i < 5 ? i * 45 : (10 - i) * 38)} l${(i % 3) - 1} ${440 + (i % 2) * 20}`} strokeWidth={5} />)}
      {[[200, 850], [800, 860]].map(([x, y]) => <g key={x}><rect x={x} y={y} width={130} height={150} fill="#15132A" /><path d={`M${x - 20} ${y + 30} l175 80 M${x - 10} ${y + 125} l165 -85`} stroke="#6B5A52" strokeWidth={24} /></g>)}
      <rect x={445} y={715} width={310} height={550} fill="#2C2638" />
      <rect x={470} y={740} width={260} height={520} fill="#05040A" />
    </g>
    <Bush x={90} y={1130} r={160} seed="o1" /><Bush x={1010} y={1180} r={170} seed="o2" /><Bush x={880} y={730} r={80} seed="o3" />
  </g>
);

const COLORS = [['#24348C', '#3F55B5'], ['#9C3B45', '#D0606A'], ['#2F7A5B', '#55AD86'], ['#B98A2E', '#E8BC55'], ['#6B4793', '#9C73C8'], ['#2E7C91', '#5BB2C9'], ['#A9A7B5', '#E4E2EE'], ['#8A4F2B', '#B97848']];
const pick = (key: string) => COLORS[Math.floor(random(key) * COLORS.length)];

const Pile = () => (
  <g>
    {Array.from({length: 270}, (_, i) => {
      const d = (i / 270) ** 1.5; // jauh -> dekat
      const side = random(`s${i}`) - 0.5;
      const [color, light] = pick(`c${i}`);
      return <Sandal key={i} x={620 + side * (480 + d * 900)} y={1010 + d * 900 - Math.abs(side) * 120 * random(`m${i}`)}
        w={(45 + d * 230) * (0.7 + random(`w${i}`) * 0.55)} color={color} light={light} rot={random(`r${i}`) * 100 - 50} broken={i % 9 === 0} />;
    })}
  </g>
);

export const SandalRoom = ({dark = 0}: {dark?: number}) => (
  <g>
    <rect x={-300} y={-300} width={1680} height={2500} fill="#10132A" />
    <path d="M300 420 H940 V990 H300Z" fill="#252B50" stroke={ink} strokeWidth={8} />
    <path d="M-100 100 L300 420 V990 L-100 1500Z" fill="#1E2342" stroke={ink} strokeWidth={8} />
    <path d="M1180 100 L940 420 V990 L1180 1500Z" fill="#191D38" stroke={ink} strokeWidth={8} />
    <path d="M300 990 H940 L1500 1920 V2100 H-400 V1920Z" fill="#211E35" />
    {/* rak kiri & kanan */}
    {[0, 1, 2, 3].map((row) => (
      <g key={row}>
        {[[-100, 330 + row * 280, 300, 500 + row * 125], [1180, 330 + row * 280, 940, 500 + row * 125]].map(([x1, y1, x2, y2], side) => (
          <g key={side}>
            <path d={`M${x1} ${y1} L${x2} ${y2}`} stroke="#6E5140" strokeWidth={22} />
            {Array.from({length: 7}, (_, i) => {
              const t = i / 7;
              const [color, light] = pick(`k${row}${side}${i}`);
              return <Sandal key={i} x={x1 + (x2 - x1) * t + (side ? -35 : 35)} y={y1 + (y2 - y1) * t - 28} w={150 * (1 - t) + 55} color={color} light={light} rot={side ? 14 : -14} />;
            })}
          </g>
        ))}
      </g>
    ))}
    {/* sandal tergantung di dinding belakang */}
    {Array.from({length: 24}, (_, i) => {
      const [color, light] = pick(`h${i}`);
      const x = 360 + (i % 8) * 75, y = 480 + Math.floor(i / 8) * 125;
      return <g key={i}><path d={`M${x} ${y - 50} v35`} stroke="#999" strokeWidth={3} /><Sandal x={x} y={y} w={66} rot={90 + (i % 3) * 8} color={color} light={light} /></g>;
    })}
    <Pile />
    <rect x={-300} y={-300} width={1680} height={2500} fill="#03030C" opacity={dark} />
  </g>
);
