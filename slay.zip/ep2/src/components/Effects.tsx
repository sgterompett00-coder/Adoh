import {random, useCurrentFrame} from 'remotion';
import {C} from '../data/layout';

export const SpeedLines = ({opacity = 0.5, y0 = 300, y1 = 1500}: {opacity?: number; y0?: number; y1?: number}) => {
  const f = useCurrentFrame();
  return (
    <g stroke="white" strokeLinecap="round" opacity={opacity}>
      {Array.from({length: 22}, (_, i) => {
        const len = 150 + random(`l${i}`) * 350;
        const x = 1300 - ((f * (70 + random(`v${i}`) * 60) + random(`o${i}`) * 1600) % 1900);
        const y = y0 + random(`y${i}`) * (y1 - y0);
        return <path key={i} d={`M${x} ${y} h${len}`} strokeWidth={3 + random(`w${i}`) * 6} />;
      })}
    </g>
  );
};

export const Dust = ({x, y, t, size = 1}: {x: number; y: number; t: number; size?: number}) => {
  if (t < 0 || t > 1) return null;
  return (
    <g fill="#C8C6DA" stroke={C.ink} strokeWidth={5} opacity={1 - t}>
      {[[0, 0, 55], [-70, 10, 42], [-135, 22, 28], [50, 20, 30]].map(([dx, dy, r], i) =>
        <circle key={i} cx={x + dx * (1 + t) * size} cy={y + dy - t * 60} r={r * (0.6 + t) * size} />)}
    </g>
  );
};

export const Mark = ({x, y, text, scale}: {x: number; y: number; text: string; scale: number}) => (
  <text transform={`translate(${x} ${y}) scale(${scale}) rotate(10)`} fontFamily="Montserrat, sans-serif" fontWeight={900}
    fontSize={150} textAnchor="middle" fill="white" stroke={C.ink} strokeWidth={16} paintOrder="stroke">{text}</text>
);

export const Vignette = ({strength = 0.7}: {strength?: number}) => (
  <>
    <defs><radialGradient id="vig" cx="50%" cy="50%" r="70%">
      <stop offset="45%" stopColor="black" stopOpacity={0} /><stop offset="100%" stopColor="black" stopOpacity={1} />
    </radialGradient></defs>
    <rect width={1080} height={1920} fill="url(#vig)" opacity={strength} />
  </>
);

export const Fog = ({y, opacity = 0.18}: {y: number; opacity?: number}) => {
  const f = useCurrentFrame();
  return (
    <g fill="#A9A6E0" opacity={opacity} style={{filter: 'blur(35px)'}}>
      {[0, 1, 2, 3, 4].map((i) => <ellipse key={i} cx={((i * 310 + f * (1 + i * 0.3)) % 1500) - 200} cy={y + (i % 2) * 60} rx={260} ry={65} />)}
    </g>
  );
};
