import {C} from '../data/layout';

const ink = C.ink;

/** Sandal jepit dengan tali Y. Pusat di (x,y), lebar w. */
export const Sandal = ({x, y, w, color = C.sandal, light = C.sandalLight, rot = 0, squash = 1, broken}:
  {x: number; y: number; w: number; color?: string; light?: string; rot?: number; squash?: number; broken?: boolean}) => {
  const k = w / 300;
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${k} ${k * squash})`}>
      <path d="M-150 5 v28 C-145 75 -70 82 0 68 C80 80 150 70 150 30 V0Z" fill={color} stroke={ink} strokeWidth={9} />
      <path d="M-150 18 C-100 70 -40 50 10 52 C70 60 130 52 150 18" fill="none" stroke="black" strokeOpacity={0.35} strokeWidth={18} />
      <path d="M-150 5 C-150 -50 -60 -42 0 -48 C90 -65 155 -45 150 0 C150 48 70 50 0 40 C-80 52 -150 45 -150 5Z" fill={color} stroke={ink} strokeWidth={9} />
      {(broken ? ['M55 -8 Q10 -75 -70 -25'] : ['M55 -8 Q10 -90 -75 -28', 'M55 -8 Q20 -30 -45 24']).map((d) => (
        <g key={d} fill="none" strokeLinecap="round">
          <path d={d} stroke={ink} strokeWidth={31} /><path d={d} stroke={light} strokeWidth={16} />
        </g>
      ))}
    </g>
  );
};

/** Jebakan: kotak + penyangga + tali. (gx,gy) = sudut kanan kotak yang menyentuh tanah. */
export const Trap = ({gx, gy, k = 1, angle = 30, rope}: {gx: number; gy: number; k?: number; angle?: number; rope?: [number, number]}) => {
  const r = (angle * Math.PI) / 180;
  const sx = gx - 520 * k * Math.cos(r) + 12 * k;
  const sy = gy - 520 * k * Math.sin(r);
  return (
    <g>
      <ellipse cx={gx - 260 * k} cy={gy + 8} rx={290 * k} ry={34 * k} fill="black" opacity={0.3} />
      <path d={`M${sx} ${gy} L${sx} ${sy}`} stroke={ink} strokeWidth={30 * k} strokeLinecap="round" />
      <path d={`M${sx} ${gy} L${sx} ${sy}`} stroke="#A9733E" strokeWidth={17 * k} strokeLinecap="round" />
      {rope && <path d={`M${sx} ${gy - 40 * k} Q${(sx + rope[0]) / 2} ${Math.max(gy, rope[1]) + 40} ${rope[0]} ${rope[1]}`} fill="none" stroke="#E6D3A5" strokeWidth={Math.max(5, 9 * k)} strokeLinecap="round" />}
      <g transform={`translate(${gx} ${gy}) scale(${k}) rotate(${angle})`} stroke={ink} strokeWidth={11} strokeLinejoin="round">
        <path d="M-520 -270 L-450 -350 H60 L0 -270Z" fill="#E0B176" />
        <path d="M0 -270 L60 -350 V-70 L0 0Z" fill="#8F6538" />
        <path d="M-520 -270 H0 V0 H-520Z" fill={C.cardboard} />
        <path d="M-300 -270 V-190 H-220 V-270" fill="#B98649" strokeWidth={6} />
      </g>
    </g>
  );
};

/** Sosok misterius: siluet tanpa wajah dan tanpa ciri khas. */
export const Shadow = ({x, y, h, opacity = 1, run = 0}: {x: number; y: number; h: number; opacity?: number; run?: number}) => (
  <g transform={`translate(${x} ${y}) scale(${h / 600})`} opacity={opacity}>
    <path d={`M-40 -190 L${-70 - run} -5 M40 -190 L${70 + run} -5`} stroke="#07060F" strokeWidth={48} strokeLinecap="round" />
    <path d="M-120 -170 C-165 -330 -105 -430 -70 -440 C-120 -520 -60 -600 5 -595 C80 -600 125 -520 75 -440 C125 -420 175 -320 125 -170 Q0 -135 -120 -170Z" fill="#07060F" stroke="#6A5FC0" strokeWidth={6} />
  </g>
);
