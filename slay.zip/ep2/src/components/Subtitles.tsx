import {loadFont} from '@remotion/google-fonts/Montserrat';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {CAPTIONS} from '../data/captions';
import {C, SUBTITLE_BOX, SUBTITLE_Y} from '../data/layout';
import {toFrame, toVideo} from '../data/timing';

const {fontFamily} = loadFont('normal', {weights: ['800'], subsets: ['latin']});

export const Subtitles = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cap = CAPTIONS.find((c) => frame >= toFrame(toVideo(c.start, true)) && frame < toFrame(toVideo(c.end)));
  if (!cap) return null;
  const pop = spring({frame: frame - toFrame(toVideo(cap.start, true)), fps, config: {damping: 11, stiffness: 220, mass: 0.6}});
  return (
    <div style={{position: 'absolute', left: SUBTITLE_BOX.x, width: SUBTITLE_BOX.width, top: SUBTITLE_Y[cap.pos],
      transform: `translateY(-50%) scale(${0.8 + 0.2 * pop})`, textAlign: 'center', fontFamily, fontWeight: 800,
      fontSize: 66, lineHeight: 1.18, color: 'white', WebkitTextStroke: `14px ${C.ink}`, paintOrder: 'stroke fill'}}>
      {cap.text.split('|').map((line) => (
        <div key={line} style={{whiteSpace: 'nowrap'}}>
          {line.split(' ').map((w, i) => (
            <span key={i} style={{color: w.startsWith('*') ? C.yellow : 'white'}}>{(i ? ' ' : '') + w.replace(/\*/g, '')}</span>
          ))}
        </div>
      ))}
    </div>
  );
};
