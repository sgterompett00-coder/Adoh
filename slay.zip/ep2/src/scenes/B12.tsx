import {Character} from '../components/Character';
import {SandalRoom} from '../components/Environment';
import {Vignette} from '../components/Effects';
import {C} from '../data/layout';
import {cam, tw, useSec} from '../lib/anim';

export const B12 = () => {
  const {s, frame} = useSec();
  if (s >= 6.85) return (
    <g>
      <rect width={1080} height={1920} fill="black" />
      <text x={540} y={980} textAnchor="middle" fontFamily="Montserrat, sans-serif" fontWeight={800} fontSize={90} fill="white" opacity={tw(s, [7.45, 7.72], [0, 1])}>BERSAMBUNG...</text>
    </g>
  );
  const pan = tw(s, [0, 2], [-120, 0]);
  const zoom = tw(s, [4.15, 6.85], [1, 1.35]);
  const red = tw(s, [1, 5], [0, 1]);
  const beat = Math.max(0, Math.sin(s * 6.5)) ** 6;
  return (
    <g>
      <g transform={cam(zoom * 1.12, 600, 860, pan)}>
        <SandalRoom dark={tw(s, [0, 3], [0.15, 0.55])} />
        <defs><radialGradient id="redglow"><stop offset="0" stopColor="#C92B35" /><stop offset="0.45" stopColor={C.red} stopOpacity={0.75} /><stop offset="1" stopColor={C.red} stopOpacity={0} /></radialGradient></defs>
        <ellipse cx={600} cy={780} rx={420} ry={470} fill="url(#redglow)" opacity={red} />
        {/* sosok: hanya puncak kepala & satu lengan; kursi membelakangi kamera */}
        <ellipse cx={600} cy={742} rx={50} ry={58} fill="#030207" stroke="#E0505A" strokeWidth={4} />
        <g stroke="#08030A" strokeWidth={8} strokeLinejoin="round">
          <path d="M470 1030 V800 Q470 765 505 765 H695 Q730 765 730 800 V1030Z" fill="#4A2630" />
          <path d="M495 1005 V805 Q495 790 510 790 H690 Q705 790 705 805 V1005Z" fill="#351A23" />
          <path d="M425 900 H480 V1050 H425Z M720 900 H775 V1050 H720Z" fill="#5C3038" />
          <path d="M470 1000 H730 V1055 H470Z" fill="#4A2630" />
          <path d="M440 1050 h30 v50 h-30Z M730 1050 h30 v50 h-30Z" fill="#241016" />
        </g>
        <path d="M722 868 Q790 866 800 905 L798 975 Q778 992 768 965 L764 912 L724 904Z" fill="#030207" stroke="#E0505A" strokeWidth={4} />
        {[540, 600, 660].map((x) => [840, 900, 960].map((y) => <circle key={`${x}-${y}`} cx={x} cy={y} r={6} fill="#8A4A50" />))}
      </g>
      <g transform={cam(1 + (zoom - 1) * 1.8, 600, 860, pan * 2)}>
        <Character head={{x: 250, y: 1210, d: 400}} expr="nervous" back />
        <path d={`M415 ${1135 + (frame % 40)} q18 28 0 37 q-18 -9 0 -37Z`} fill="#8FD3FF" opacity={s > 2 ? 0.9 : 0} />
      </g>
      <Vignette strength={0.7 + beat * 0.3} />
    </g>
  );
};
