import {Character} from '../components/Character';
import {SandalRoom} from '../components/Environment';
import {Vignette} from '../components/Effects';
import {Sandal} from '../components/Props';
import {cam, tw, useSec} from '../lib/anim';

export const B11 = () => {
  const {s, frame} = useSec();
  const pan = tw(s, [2.3, 3.2, 4.2, 5.85], [0, 120, -120, -120]);
  const turn = Math.sin(tw(s, [2, 4.3], [0, Math.PI * 2]));
  const fall = tw(s, [4.6, 4.95], [0, 1]);
  return (
    <g>
      <g transform={cam(tw(s, [0, 2.3], [1.2, 1]) + 0.12, 620, 860, pan)}>
        <SandalRoom />
        <path d="M640 -100 V510" stroke="#0B0A0D" strokeWidth={10} />
        <path d="M570 560 L640 500 L710 560Z" fill="#59607E" stroke="#0B0A0D" strokeWidth={9} />
        <path d="M590 562 L330 1450 H950 L690 562Z" fill="#CFE0FF" opacity={0.13} />
        <ellipse cx={640} cy={566} rx={52} ry={18} fill="#EAF2FF" />
        {s > 4.6 && <Sandal x={830} y={400 + fall * fall * 760} w={150} color="#9C3B45" light="#D0606A" rot={fall * 310} />}
        {/* sandal utama (yang baru dicuri) */}
        <Sandal x={770} y={1330} w={290} />
        <circle cx={850} cy={1280} r={8 + (frame % 20) / 2} fill="white" opacity={0.5} />
      </g>
      <Character head={{x: tw(s, [0.3, 2], [80, 250]) + turn * 25, y: 1150, d: 440}} expr={s > 4.4 ? 'confused' : 'shocked'}
        faceShift={s > 4.9 ? 45 : turn * 55} look={s > 4.9 ? 18 : turn * 18} tilt={turn * 6} />
      <Vignette strength={0.6} />
      <rect width={1080} height={1920} fill="#D6E2FF" opacity={tw(s, [0, 0.35], [1, 0])} />
    </g>
  );
};
