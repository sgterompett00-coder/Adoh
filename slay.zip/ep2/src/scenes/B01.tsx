import {Character} from '../components/Character';
import {Bush, Yard} from '../components/Environment';
import {Dust, Mark, SpeedLines} from '../components/Effects';
import {Sandal} from '../components/Props';
import {cam, shake, tw, useSec} from '../lib/anim';

export const B01 = () => {
  const {frame, s} = useSec();
  const twitch = (a: number) => (s > a && s < a + 0.25 ? Math.sin(((s - a) / 0.25) * Math.PI) : 0);
  const t = twitch(0.3) + twitch(0.75);
  const sandal = (x: number, y: number, w: number) => <Sandal x={x} y={y - t * 55} w={w} rot={t * -12} squash={1 - t * 0.12} />;
  if (s < 1.2) return (
    <g transform={cam(tw(s, [0, 1.2], [1, 1.08]), 480, 1100)}>
      <Yard />
      <g style={{filter: 'blur(4px)'}}><Character feet={{x: 810, y: 960, h: 520}} expr={s > 0.5 ? 'shocked' : 'curious'} look={-14} /></g>
      <Bush x={150} y={870} r={280} seed="main" />
      {sandal(480, 1130, 640)}
      {t > 0 && <path d="M800 960 l60 -70 M850 1040 l90 -30" stroke="white" strokeWidth={16} strokeLinecap="round" />}
    </g>
  );
  if (s < 2.2) {
    const j = shake(frame, tw(s, [1.2, 1.4], [40, 0]));
    return (
      <g transform={cam(tw(s, [1.2, 1.35, 2.2], [1.25, 1.1, 1.15]), 540, 920, j.x, j.y)}>
        <g style={{filter: 'blur(6px)'}}><Yard pan={-150} /></g>
        <Character head={{x: 540, y: 1000 + tw(s, [1.8, 2.15], [0, 50]), d: 660}} expr="shocked" tilt={tw(s, [1.8, 2.15], [0, 10])} />
        <Mark x={900} y={720} text="!?" scale={tw(s, [1.2, 1.35, 1.5], [0, 1.3, 1])} />
      </g>
    );
  }
  // freeze 6 frame lalu melesat
  const r = Math.max(0, s - 2.4);
  const x = tw(r, [0.15, 1.1, 2], [400, 620, 1400]);
  const step = Math.sin(r * 28);
  return (
    <g>
      <Yard pan={-r * 130} />
      {sandal(120 - r * 300, 1230, 260)}
      <SpeedLines opacity={r > 0 ? 0.45 : 0} />
      <Dust x={x - 190} y={1220} t={r > 0 ? (r * 2.5) % 1 : -1} />
      {r > 0 ? (
        <Character feet={{x, y: 1240 - Math.abs(step) * 35, h: 700}} expr="panicked" lean={17}
          handL={[-190, -300 + step * 110]} handR={[200, -300 - step * 110]}
          footL={[-120 * step - 30, -20 - Math.max(0, step) * 90]} footR={[120 * step + 30, -20 - Math.max(0, -step) * 90]} />
      ) : (
        <Character feet={{x: 400, y: 1240, h: 700}} expr="panicked" lean={-14} squash={0.86} />
      )}
    </g>
  );
};
