import {Character} from '../components/Character';
import {Wall, Yard, Bush} from '../components/Environment';
import {Sandal, Trap} from '../components/Props';
import {cam, tw, useSec} from '../lib/anim';

export const B05 = () => {
  const {s, frame} = useSec();
  const asleep = s >= 3.4 && s < 4.75;
  const yawn = s >= 2.4 && s < 3.4;
  const nod = tw(s, [3.4, 4.1, 4.4, 4.7, 4.75, 4.9], [0, 80, 55, 110, -35, 0]);
  const bubble = asleep ? 30 + Math.abs(Math.sin(frame / 6)) * 45 : 0;
  return (
    <g transform={cam(tw(s, [0, 4.85, 5.09], [1, 1.03, 1.2]), 540, 1080)}>
      <Yard dim={tw(s, [0, 3], [0.05, 0.3])} moon={[tw(s, [1.2, 2.4], [660, 880]), 400]} lightOff={s > 1.9} horizon={1050} />
      <Trap gx={850} gy={1260} k={0.54} rope={[300, 1330]} />
      <Sandal x={700} y={1240} w={135} />
      <Character head={{x: 450, y: 1040 + nod, d: 360}} expr={yawn || asleep ? 'exhausted' : s >= 4.75 ? 'shocked' : 'suspicious'}
        tilt={10 + nod / 4} look={s < 1.2 ? Math.sin(frame / 5) * 18 : 10} handR={yawn ? [90, -430] : [60, -180]} />
      <Wall edge={340} />
      {bubble > 0 && <circle cx={675} cy={950 - bubble / 2} r={bubble} fill="#BFE3FF" fillOpacity={0.55} stroke="white" strokeWidth={6} />}
      <circle cx={345} cy={1260 + nod} r={30} fill="#0B0A0D" />
      <Bush x={150} y={1720} r={260} seed="fg" blur={6} />
    </g>
  );
};
