import {Character} from '../components/Character';
import {Wall, Yard, Bush} from '../components/Environment';
import {Dust} from '../components/Effects';
import {Sandal} from '../components/Props';
import {cam, tw, useSec} from '../lib/anim';

export const B02 = () => {
  const {s, frame} = useSec();
  const walking = s >= 0.8 && s < 2.2;
  const hop = walking ? Math.abs(Math.sin(((s - 0.8) / 1.4) * Math.PI * 3)) : 0;
  const crouch = tw(s, [2.2, 2.5], [0, 1]);
  const lift = tw(s, [2.65, 3], [0, 1]);
  return (
    <g transform={cam(tw(s, [0, 3.04], [1, 1.12]), 620, 1100)}>
      <Yard />
      <Bush x={870} y={1140} r={190} seed="near" />
      {lift === 0 && <Sandal x={760} y={1240} w={220} />}
      {walking && <Dust x={tw(s, [0.8, 2.2], [330, 620])} y={1300} t={((s - 0.8) * 2.1) % 1} size={0.45} />}
      {s < 0.8 ? (
        <Character head={{x: tw(s, [0, 0.3], [180, 375]), y: 900, d: 380}} expr="suspicious" tilt={14} look={Math.sin(frame / 4) * 18} />
      ) : (
        <Character feet={{x: tw(s, [0.8, 2.2], [330, 620]), y: 1300 - hop * 45, h: 620}} expr="curious"
          lean={walking ? 9 : crouch * 18} squash={1 - crouch * 0.18}
          handL={walking ? [20, -270] : [-130, -170]}
          handR={walking ? [100, -270] : [tw(s, [2.2, 2.65, 3], [145, 215, 200]), tw(s, [2.2, 2.65, 3], [-185, -75, -270])]}
          footL={[-55 - hop * 40, -8 - hop * 50]} footR={[55 + hop * 30, -8]}
          holdR={lift > 0 ? <Sandal x={25} y={30} w={170} rot={35} /> : undefined} />
      )}
      <Wall edge={330} />
      {[0, 1, 2].map((i) => <ellipse key={i} cx={500 + i * 200 + Math.sin(s * 3 + i) * 50} cy={550 + s * (150 + i * 40) + i * 90} rx={20} ry={9} fill="#2B5E47" transform={`rotate(${Math.sin(s * 4 + i) * 12} 540 900)`} />)}
    </g>
  );
};
