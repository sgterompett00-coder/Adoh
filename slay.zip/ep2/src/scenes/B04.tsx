import {Character} from '../components/Character';
import {Yard} from '../components/Environment';
import {Mark} from '../components/Effects';
import {Sandal, Trap} from '../components/Props';
import {cam, freeze, shake, tw, useSec} from '../lib/anim';

export const B04 = () => {
  const {s: real, frame} = useSec();
  const s = freeze(real, 1.09, 0.27);
  const angle = tw(s, [0, 0.5, 0.65, 1.09, 1.4, 1.65], [24, 30, 30, 7, 24, 30]);
  const catching = s > 0.65 && s < 1.55;
  const tying = s >= 1.6 && s < 4.3;
  const done = s >= 4.3;
  const j = shake(frame, tw(real, [1.09, 1.12, 1.35], [0, 45, 0]));
  // close-up simpul yang longgar (setup untuk B07)
  if (s >= 2.7 && s < 3.5) return (
    <g transform={cam(tw(s, [2.7, 3.5], [1, 1.1]))}>
      <rect width={1080} height={1920} fill="#2A2438" />
      <path d="M520 100 L590 1900" stroke="#A9733E" strokeWidth={180} />
      <path d={`M0 1280 Q300 1150 550 930 C760 760 820 1120 560 1060 C430 1020 480 ${860 + Math.sin(frame / 2) * 20} ${690 + tw(s, [3.1, 3.5], [0, 70])} 850`} fill="none" stroke="#E6D3A5" strokeWidth={38} strokeLinecap="round" />
      <circle cx={430 + Math.sin(frame / 3) * 30} cy={1040} r={95} fill="#0B0A0D" />
    </g>
  );
  const zoom = (s >= 0.65 && s < 1.7) ? 1.3 : 1;
  return (
    <g transform={cam(zoom, 480, 1000, j.x, j.y)}>
      <Yard />
      <Sandal x={650} y={1235} w={260} />
      <Trap gx={900} gy={1270} angle={angle} rope={tying || done ? [done ? 190 : 330, done ? 1300 : 1170 + Math.sin(frame / 2) * 25] : undefined} />
      <Character feet={{x: 240, y: 1290, h: 560}} expr={catching ? 'panicked' : done ? 'smug' : 'determined'}
        lean={tying ? 20 : catching ? 12 : 0} squash={catching ? 0.84 : tying ? 0.84 : 1 + (done ? Math.abs(Math.sin(frame / 4)) * 0.06 : 0)}
        handL={done ? [-25 - Math.abs(Math.sin(frame / 2)) * 50, -280] : catching ? [150, -560] : [90, -180]}
        handR={done ? [25 + Math.abs(Math.sin(frame / 2)) * 50, -280] : catching ? [290, -500] : [235, tying ? -170 + Math.sin(frame / 2) * 35 : -260]} />
      {real > 1.09 && real < 1.4 && <Mark x={430} y={640} text="✦" scale={1.2} />}
      {real > 4.65 && <Mark x={790} y={640} text="✦" scale={tw(real, [4.65, 4.85, 5.3], [0, 1.2, 0.8])} />}
    </g>
  );
};
