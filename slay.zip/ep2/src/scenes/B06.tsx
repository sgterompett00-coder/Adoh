import {Character} from '../components/Character';
import {Wall, Yard} from '../components/Environment';
import {Fog, Vignette} from '../components/Effects';
import {Sandal, Shadow, Trap} from '../components/Props';
import {cam, tw, useSec} from '../lib/anim';

export const B06 = () => {
  const {s, frame} = useSec();
  if (s >= 1.2 && s < 2.4) return (
    <g transform={cam(tw(s, [1.2, 2.4], [1, 1.12]), 560, 800)}>
      <rect width={1080} height={1920} fill="#12152B" />
      <Character head={{x: 560, y: 800, d: 800}} expr="nervous" look={16 + Math.sin(frame * 2) * 3} />
      <Wall edge={190} />
      {[0, 1, 2, 3].map((i) => <ellipse key={i} cx={190 + Math.sin(frame) * 3} cy={920 + i * 75} rx={65} ry={30} fill="#0B0A0D" />)}
      <Vignette />
    </g>
  );
  // gerak tersendat: dibulatkan ke langkah-langkah kecil
  const step = Math.floor(s * 5) / 5;
  const near = tw(step, [2.4, 4.9], [0, 1]);
  return (
    <g transform={cam(tw(s, [0, 5.06], [1, 1.18]), 800, 1000)}>
      <Yard dim={0.35} horizon={840} />
      <rect x={640} y={560} width={380} height={380} fill="#05040F" opacity={0.65} style={{filter: 'blur(40px)'}} />
      <ellipse cx={820} cy={900 + near * 150} rx={tw(s, [0, 1.2], [10, 130])} ry={22 + near * 25} fill="black" opacity={0.7} />
      <Shadow x={820} y={880 + near * 190} h={160 + near * 330} opacity={tw(s, [2.4, 3], [0, 1])} run={Math.sin(step * 16) * 35} />
      <Fog y={900} opacity={0.22} />
      <Trap gx={700} gy={1290} k={1} angle={32} />
      <Sandal x={390} y={1260} w={400} />
      <Vignette strength={0.85} />
    </g>
  );
};
