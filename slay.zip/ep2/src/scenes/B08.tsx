import {Character} from '../components/Character';
import {Alley} from '../components/Environment';
import {Dust, SpeedLines} from '../components/Effects';
import {Sandal, Shadow} from '../components/Props';
import {cam, shake, tw, useSec} from '../lib/anim';

export const B08 = () => {
  const {s, frame} = useSec();
  const step = Math.sin(s * 25);
  const trip = s > 1.65 && s < 2.35;
  const turn = tw(s, [2.6, 3.4], [0, 1]);
  const drift = tw(s, [3.4, 4.1], [0, 1]);
  const j = shake(frame, trip ? 30 : 7);
  const x = tw(s, [0, 0.5, 3.4, 4.1], [80, 340, 340, 820]);
  const jump = s < 0.5 ? Math.sin((s / 0.5) * Math.PI) * 220 : 0;
  const bucket = tw(s, [1, 1.65], [1250, 450]);
  const figX = 760 + turn * 150, figY = 1100 - turn * 200, figH = 420 - turn * 270;
  return (
    <g transform={cam(1.04, 540, 960, j.x, j.y)}>
      <Alley scroll={s * 0.9} />
      <g opacity={tw(s, [3.2, 3.45], [1, 0])}>
        <Shadow x={figX} y={figY} h={figH} run={step * 70} />
        <Sandal x={figX + figH * 0.32} y={figY - figH * 0.55} w={figH * 0.3} rot={-35 + step * 15} />
        {s > 2.7 && <circle cx={figX + figH * 0.32} cy={figY - figH * 0.55} r={14 + (frame % 6) * 3} fill="white" opacity={0.7} />}
      </g>
      {s > 1 && (
        <g transform={`translate(${bucket - (trip ? (s - 1.65) * 500 : 0)} ${1220 - (trip ? Math.sin((s - 1.65) * 4.4) * 220 : 0)}) rotate(${trip ? (s - 1.65) * 400 : 0})`}>
          <path d="M-60 -90 H60 L45 30 H-45Z" fill="#6D8796" stroke="#0B0A0D" strokeWidth={9} />
        </g>
      )}
      <SpeedLines opacity={0.35} y0={500} y1={1250} />
      <Dust x={x - 200} y={1250} t={(s * 2.8) % 1} />
      <Character feet={{x: x + drift * 20, y: 1260 - jump - Math.abs(step) * 30 - drift * 200, h: 640 - drift * 250}}
        expr={trip ? 'panicked' : 'determined'} lean={trip ? 33 : 18 + drift * 15}
        squash={s < 0.12 ? 0.75 : s < 0.35 ? 1.14 : 1}
        handL={[-200, -310 + step * 120]} handR={[200, -310 - step * 120]}
        footL={[-130 * step - 30, -20 - Math.max(0, step) * 100]} footR={[130 * step + 30, -20 - Math.max(0, -step) * 100]} />
      {/* tiang foreground = wipe ke B09 */}
      <rect x={tw(s, [3.8, 4.1], [1250, -200])} y={-100} width={tw(s, [3.8, 4.1], [200, 1500])} height={2100} fill="#07060F" />
    </g>
  );
};
