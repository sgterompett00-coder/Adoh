import {Character} from '../components/Character';
import {Vignette} from '../components/Effects';
import {cam, tw, useSec} from '../lib/anim';

export const B10 = () => {
  const {s, frame} = useSec();
  // pintu terbuka perlahan, tertahan sekali
  const open = tw(s, [2.6, 3.3, 3.7, 4.8], [0.04, 0.35, 0.37, 1]);
  const peek = tw(s, [3.8, 4.5], [0, 1]);
  const through = tw(s, [4.8, 5.7], [0, 1]);
  const edge = 380 + 360 * open;
  const hand = tw(s, [0.9, 1.25, 1.4, 1.6], [0, 1, 0.75, 1]);
  const flash = s > 5.4 ? (frame % 3 === 0 ? 0.25 : tw(s, [5.4, 5.7], [0.2, 1])) : 0;
  return (
    <g>
      <g transform={cam(tw(s, [0, 4.8], [1, 1.25]) + through * 1.1, 580, 850)}>
        <rect x={-300} y={-300} width={1680} height={2500} fill="#3B3A56" />
        {Array.from({length: 12}, (_, i) => <path key={i} d={`M${-90 + i * 115} -300 l${(i % 3) * 8} 2500`} stroke="#0B0A0D" strokeWidth={6} />)}
        <rect x={355} y={395} width={570} height={1050} fill="#2B2230" stroke="#0B0A0D" strokeWidth={12} />
        <rect x={380} y={420} width={520} height={1000} fill="#030207" />
        <path d={`M380 420 L${edge} 1420 L${edge + 90} 1920 L200 1920 L380 1420Z`} fill="#8EA2E8" opacity={open * 0.2} />
        <path d={`M${edge} ${420 + open * 55} L900 420 V1420 L${edge} ${1420 - open * 55}Z`} fill="#70503F" stroke="#0B0A0D" strokeWidth={12} />
        {[0.25, 0.5, 0.75].map((t) => <path key={t} d={`M${edge + (900 - edge) * t} ${460} V1380`} stroke="#3F2C26" strokeWidth={6} />)}
        <circle cx={edge + 70} cy={1000} r={30} fill="#C9A45A" stroke="#0B0A0D" strokeWidth={9} />
        <path d="M900 420 q-120 20 -150 130 M900 420 q-60 90 -50 170 M790 440 q20 60 90 80" fill="none" stroke="white" strokeWidth={3} opacity={0.5} />
        {s > 1.2 && peek < 0.1 && <g><path d={`M180 1370 Q330 1220 ${300 + hand * (edge - 240)} ${1200 - hand * 200}`} fill="none" stroke="#0B0A0D" strokeWidth={48} strokeLinecap="round" /><circle cx={300 + hand * (edge - 240)} cy={1200 - hand * 200} r={46} fill="#0B0A0D" /></g>}
        {Array.from({length: 25}, (_, i) => <circle key={i} cx={420 + ((i * 97) % 440)} cy={450 + ((i * 173 + frame * (1 + (i % 3))) % 950)} r={3 + (i % 3)} fill="#DCE4FF" opacity={open * 0.6} />)}
      </g>
      <g opacity={1 - through} transform={`translate(${-through * 500} ${through * 200})`}>
        {peek === 0
          ? <Character head={{x: tw(s, [0, 1.2], [70, 230]), y: 1130, d: 520}} expr="curious" back />
          : <Character head={{x: 230 + peek * 230, y: 1130 - peek * 280, d: 520 - peek * 100}} expr="nervous" tilt={peek * 15} look={18} faceShift={20} />}
      </g>
      <Vignette strength={0.7} />
      <rect width={1080} height={1920} fill="#D6E2FF" opacity={flash} />
    </g>
  );
};
