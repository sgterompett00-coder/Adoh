import {Character} from '../components/Character';
import {Wall, Yard} from '../components/Environment';
import {Mark, Vignette} from '../components/Effects';
import {Sandal, Shadow, Trap} from '../components/Props';
import {cam, freeze, shake, tw, useSec} from '../lib/anim';

export const B07 = () => {
  const {s: real, frame} = useSec();
  if (real < 1.6) {
    const reach = tw(real, [0, 0.7, 0.95, 1.1], [1350, 880, 910, 770]);
    const lift = tw(real, [1.15, 1.3, 1.6], [0, 60, 520]);
    const j = shake(frame, real > 1.15 && real < 1.35 ? 18 : 0);
    return (
      <g transform={cam(tw(real, [0, 1.6], [1, 1.08]), 540, 1000, j.x, j.y)}>
        <g style={{filter: 'blur(8px)'}}><Yard dim={0.45} horizon={760} /></g>
        <path d="M40 420 L1040 330 L1000 560 L80 640Z" fill="#8F6538" stroke="#0B0A0D" strokeWidth={14} />
        <path d={`M0 1350 Q200 1290 ${300 + lift * 0.1} ${1330 - lift * 0.08}`} fill="none" stroke="#E6D3A5" strokeWidth={18} />
        <ellipse cx={540} cy={1160} rx={400} ry={60} fill="black" opacity={0.4} />
        <Sandal x={540 + lift * 0.4} y={1050 - lift} w={760} rot={-lift / 25} />
        <g transform={`translate(${reach + lift * 0.4} ${1000 - lift})`} fill="#07060F" stroke="#6A5FC0" strokeWidth={8}>
          <path d="M800 -150 L170 -90 C80 -130 -60 -80 -50 -35 L60 -35 C-50 0 -40 50 70 40 C0 80 40 130 180 90 L800 130Z" />
        </g>
        <Vignette />
      </g>
    );
  }
  if (real < 2.2) return (
    <g transform={cam(tw(real, [1.6, 1.75], [1.2, 1]), 540, 820)}>
      <rect width={1080} height={1920} fill="#1B2347" />
      <Character head={{x: 540, y: 820, d: 720}} expr="shocked" look={18} />
      <Mark x={900} y={560} text="!!" scale={tw(real, [1.65, 1.8, 1.95], [0, 1.3, 1])} />
    </g>
  );
  const s = freeze(real, 2.45, 0.2);
  const pull = tw(s, [2.2, 2.45], [0, 1]);
  return (
    <g>
      <Yard dim={0.3} />
      <Shadow x={tw(s, [2.2, 2.9], [890, 1250])} y={1130} h={420} run={Math.sin(frame) * 40} />
      <Trap gx={900} gy={1220} k={0.82} />
      {/* ujung tali lepas */}
      <path d={`M${300 - pull * 70} 1050 Q${420 - pull * 80} ${1300 - pull * 400} ${480 - pull * 130} ${1220 - pull * 480 * tw(s, [2.45, 3.1], [1, 0.1])}`} fill="none" stroke="#E6D3A5" strokeWidth={14} strokeLinecap="round" />
      <Character feet={{x: 290, y: 1290, h: 600}} expr={s > 2.5 ? 'confused' : 'determined'} lean={-pull * 14} handR={[145 - pull * 40, -300 - pull * 70]} />
      <Wall edge={90} />
    </g>
  );
};
