import {Character} from '../components/Character';
import {OldBuilding} from '../components/Environment';
import {Dust, Fog, Vignette} from '../components/Effects';
import {Shadow} from '../components/Props';
import {cam, tw, useSec} from '../lib/anim';

export const B09 = () => {
  const {s, frame} = useSec();
  const arrived = s >= 1.2;
  const look = tw(s, [2.4, 2.9], [0, 1]);
  const pant = s > 1.3 && s < 2.4 ? Math.abs(Math.sin(frame / 3)) : 0;
  const x = tw(s, [0.5, 1.2], [-200, 270]);
  const door = Math.sin(s * 2.2) * 18;
  return (
    <g transform={cam(tw(s, [0, 3.45], [1, 1.15]), 600, 1000)}>
      <OldBuilding />
      <Shadow x={600} y={tw(s, [0, 0.9], [1330, 1230])} h={tw(s, [0, 0.9], [430, 330])} opacity={tw(s, [0.55, 0.9], [1, 0])} run={Math.sin(frame) * 30} />
      <path d={`M470 740 L${560 + door} 765 V1235 L470 1260Z`} fill="#6A4F40" stroke="#0B0A0D" strokeWidth={9} />
      <Fog y={1280} />
      <Dust x={x - 130} y={1360} t={(s - 0.8) * 1.4} />
      <Character feet={{x, y: 1370, h: 520}} expr={look > 0.5 ? 'suspicious' : arrived ? 'exhausted' : 'determined'}
        lean={arrived ? (1 - look) * 22 : -16} squash={arrived ? 0.9 + look * 0.1 + pant * 0.05 : 1}
        handL={arrived && look < 0.5 ? [-35, -110] : [-145, -185]} handR={arrived && look < 0.5 ? [110, -110] : [145, -185]}
        footR={arrived ? [55, -8] : [140, -15]} faceShift={look * 35} look={look * 15} />
      {pant > 0.5 && <ellipse cx={x + 190} cy={1070} rx={55} ry={28} fill="white" opacity={0.3} />}
      <Vignette strength={0.6} />
    </g>
  );
};
