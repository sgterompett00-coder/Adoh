import {spring} from 'remotion';
import {Character} from '../components/Character';
import {Yard} from '../components/Environment';
import {Sandal, Trap} from '../components/Props';
import {cam, tw, useSec} from '../lib/anim';

export const B03 = () => {
  const {s, frame, fps} = useSec();
  const up = spring({frame: frame - Math.round(0.85 * fps), fps, config: {damping: 9, stiffness: 180}});
  const idea = s >= 0.85;
  if (s < 3.4) {
    const rays = tw(s, [0.85, 1.2], [0, 1]);
    return (
      <g transform={cam(tw(s, [0.82, 1.1], [1, 1.14]), 520, 800)}>
        <g style={{filter: 'blur(5px)'}}><Yard /></g>
        {idea && (
          <g transform={`translate(800 430) scale(${up})`}>
            <circle r={150} fill="#FFE68A" opacity={0.2} />
            {Array.from({length: 10}, (_, i) => <path key={i} d="M0 -105 v-55" transform={`rotate(${i * 36 + frame})`} stroke="#FFE68A" strokeWidth={10} strokeLinecap="round" opacity={rays} />)}
            <circle r={65} fill="#FFE15A" stroke="#0B0A0D" strokeWidth={10} />
            <path d="M-30 55 h60 v55 h-60Z" fill="#9A9AA8" stroke="#0B0A0D" strokeWidth={9} />
          </g>
        )}
        <Character head={{x: 440, y: 790, d: 530}} expr={idea ? 'smug' : 'confused'} tilt={idea ? -4 : 7}
          look={s > 1.6 ? 14 : 0}
          handL={idea ? [-150, -190] : [-170 + Math.sin(frame) * 14, -590]}
          handR={[145 + up * 75, -190 - up * 300]} pointR={idea}
          holdR={s < 0.85 ? <Sandal x={40} y={0} w={170} rot={20} /> : undefined} />
        {idea && <Sandal x={170} y={1130 + Math.sin(frame / 5) * 12} w={250} rot={-15} />}
      </g>
    );
  }
  const place = tw(s, [3.4, 4.5], [0, 1]);
  const box = tw(s, [4.6, 5.7], [0, 1]);
  return (
    <g transform={cam(tw(s, [3.4, 5.95], [1.12, 1]), 620, 1100, tw(s, [3.4, 4.2], [220, 0]))}>
      <Yard pan={tw(s, [3.4, 4.2], [200, 0])} />
      <ellipse cx={620} cy={1225} rx={60 + box * 220} ry={20 + box * 45} fill="black" opacity={box * 0.5} />
      <Sandal x={620} y={tw(s, [3.4, 4.1, 4.5], [850, 1220, 1200])} w={300} squash={s > 4.1 && s < 4.35 ? 0.82 : 1} />
      <Character feet={{x: 230, y: 1300, h: 540}} expr="smug" lean={(1 - place) * 20} handR={[210, -190 - box * 210]} />
      {box > 0 && <Trap gx={900} gy={1270 - (1 - box) * 100 - 230 * (1 - tw(s, [5.5, 5.9], [0, 1])) * box} angle={18} rope={[360, 1110]} />}
    </g>
  );
};
