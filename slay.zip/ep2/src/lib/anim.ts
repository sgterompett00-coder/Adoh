import {Easing, interpolate, random, useCurrentFrame, useVideoConfig} from 'remotion';

/** Detik lokal di dalam beat. */
export const useSec = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return {frame, fps, s: frame / fps};
};

export const tw = (s: number, input: number[], output: number[]) =>
  interpolate(s, input, output, {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.quad)});

export const shake = (frame: number, power: number) => ({
  x: (random(`x${frame}`) - 0.5) * power, y: (random(`y${frame}`) - 0.5) * power,
});

/** Freeze frame: tahan waktu selama `len` detik mulai `at`. */
export const freeze = (s: number, at: number, len: number) => (s < at ? s : s < at + len ? at : s - len);

/** Transform kamera: zoom pada titik (ax, ay) lalu geser. */
export const cam = (scale: number, ax = 540, ay = 960, dx = 0, dy = 0) =>
  `translate(${ax + dx} ${ay + dy}) scale(${scale}) translate(${-ax} ${-ay})`;
